// Basic analytics
document.addEventListener('DOMContentLoaded', function() {
  console.log('Page viewed:', window.location.pathname);
});